from Clase_Atenciones import Atenciones
import csv
import numpy as np

class ManejadorA:
    __cantidad: int
    __dimension: int
    __incremento = 1
    __ArreA: np.ndarray
    
    def __init__(self, dimension=10, incremento=1):
        self.__ArreA = np.empty(dimension, dtype=Atenciones)
        self.__cantidad = 0
        self.__dimension = dimension
    
    def agregar_atencion(self, unaAtencion):
        if self.__cantidad==self.__dimension:
            self.__dimension+=self.__incremento
            self.__ArreA.resize(self.__dimension)
        self.__ArreA[self.__cantidad]=unaAtencion
        self.__cantidad += 1
    
    def cargar_atenciones(self):
        archivo = open("atenciones.csv")
        reader = csv.reader(archivo, delimiter=";")
        bandera = True
        for fila in reader:
            if bandera:
                bandera = False
            else:
                unaAtencion = Atenciones(fila[0], fila[1],int(fila[2]))
                self.agregar_atencion(unaAtencion)
        archivo.close()
    
    def incisoA(self, fecha):
        cont = 0
        importe = 0
        for i in range(self.__cantidad):
            if self.__ArreA[i].get_fecha() == fecha:
                cont += 1
                importe += self.__ArreA[i].get_importe()
        if cont > 0:
            print(f"\n Las atenciones realizadas en la fecha {fecha} son {cont}. Importe total: {importe}")
        else:
            print(f"\n No se encontraron atenciones en la fecha {fecha}")
    
    def contar_atenciones(self, dni):
        cont = 0
        for i in range(self.__cantidad):
            if self.__ArreA[i].get_dni() == dni:
                cont += 1
        return cont