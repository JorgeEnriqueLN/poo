from Manejador_Atenciones import ManejadorA
from Manejador_Paciente import ManejadorP

def main():
    ma = ManejadorA()
    mp = ManejadorP()
    ma.cargar_atenciones()
    print(f"\n Atenciones Cargadas.")
    mp.cargar_pacientes()
    print(f"\n Pacientes Cargados.")
    opcion = 100
        
    while opcion != 0:
        print("\n MENU DE OPCIONES \n")
        print("1. Opcion 1.")
        print("2. Opcion 2")
        print("3. Opcion 3")
        print("4. Opcion 4")
        print("0. Salir.")
        opcion = int(input("Ingrese el número de la opción que desea: "))
    
        if opcion == 1:
            fecha = input("Ingrese una fecha: ")
            ma.incisoA(fecha)
            
        elif opcion == 2:
            dni = input("Ingrese un dni a buscar: ")
            mp.incisoB(dni, ma)
            
        elif opcion == 3:
            mp.incisoC(ma)

        elif opcion == 4:
            mp.incisoD()
        
        elif opcion == 0:
            print(f"\n Hasta luego.")
        else:
            print("\nERROR - Opción inválida")

if __name__=="__main__":
    main()