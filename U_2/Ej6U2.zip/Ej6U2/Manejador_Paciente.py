import csv
from Clase_Paciente import Paciente

class ManejadorP:
    __lista: list
    
    def __init__(self):
        self.__lista = []
        
    def agregar_paciente(self, paciente):
        self.__lista.append(paciente)    
    
    def cargar_pacientes(self):
        archivo = open("pacientes.csv")
        reader = csv.reader(archivo, delimiter=";")
        bandera = True
        for fila in reader:
            if bandera:
                bandera = False
            else:
                unPaciente = Paciente(fila[0], fila[1], fila[2])
                self.agregar_paciente(unPaciente)
        archivo.close()
    
    def incisoB(self, dni, ma):
        encontrado = False
        i = 0
        while not encontrado and i < len(self.__lista):
            if self.__lista[i].get_dni() == dni:
                encontrado = True
            else: 
                i += 1
                
        if encontrado:
            cantidad_atenciones = ma.contar_atenciones(dni)
            print(f"\n El paciente: {self.__lista[i].get_nombre()} - DNI: {dni} - Tiene {cantidad_atenciones} atenciones.")
        else:
            print(f"\n No se encontro un paciente con DNI: {dni}")
    
    def incisoC(self, ma):
        encontrado = False
        cant = 0
        i = 0
        for paciente in self.__lista:
            cant = ma.contar_atenciones(paciente.get_dni())
            if cant == 0:
                print(paciente)
                encontrado = True
            
        if not encontrado:
            print(f"\n No hay pacientes sin atencion.")
            
    def incisoD(self):
        self.__lista.sort()
        print(f"\n Listado de pacientes ordenados por unidad y apellido")
        unidad_actual = ""
        for paciente in self.__lista:
            if paciente.get_unidad() != unidad_actual:
                unidad_actual = paciente.get_unidad()
                print(f"\n-----{unidad_actual}-----")
            print(paciente)
            