# POO2025

## 📚 Descripción
Repositorio de ejercicios y trabajos prácticos de **Programación Orientada a Objetos** para la **UNSJ - Año 2025**.  
Los ejercicios están desarrollados en **Python**.
