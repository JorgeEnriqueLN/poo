from ManejadorDepartamentos import ManejadorDepartamentos
from Accidente import Accidente
from menu import main_menu

def main():
  main_menu()

if __name__ == "__main__":
    main()
