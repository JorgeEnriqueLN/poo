from Test import Test
if __name__ == "__main__":
    Test()
