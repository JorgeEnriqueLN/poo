from menu import main_menu

def main():
  main_menu()

if __name__ == "__main__":
  main()
