#Ormeño Agustin / E010-270
from test import test

if __name__ == '__main__':
    test()