from Visualizacion import Visualizacion
import csv

class GestorVisualizaciones:
    __Visualizaciones: list

    def __init__(self):
        self.__Visualizaciones = []

    def agregar(self, visual):
        self.__Visualizaciones.append(visual)

    def cargar(self, ruta):
        archi = open(ruta)
        reader = csv.reader(archi, delimiter=';')
        band = True
        for fila in reader:
            if band:
                band = not band
            else: 
                visualizacion = Visualizacion(int(fila[0]),fila[1],fila[2],fila[3], int(fila[4]))
                self.agregar(visualizacion)
        archi.close 

    def __str__(self):
        s = ""
        for visual in self.__Visualizaciones:
            s += str(visual) + "\n" 
        return s
    
    def mostrarMinutos(self, id: int):
        acum = 0
        for visua in self.__Visualizaciones:
            if visua.getIdMiem() == id:
                acum+= visua.getMinVisua()
        print(f"El total de minutos del usuario dueno del correo ingresado fue de {acum}m")

    def mostrarDatosSimultaneas(self, gm):
        i = 0
        j = 0
        while i<len(self.__Visualizaciones):
            while j < len(self.__Visualizaciones):
                if self.__Visualizaciones[i] == self.__Visualizaciones[j+1]:
                    gm.mostrarDatos(self.__Visualizaciones[i].getIdMiem())
                    j += 1
            i += 1
                
                
