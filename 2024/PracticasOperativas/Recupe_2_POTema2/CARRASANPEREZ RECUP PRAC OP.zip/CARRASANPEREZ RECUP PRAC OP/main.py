from manejaVisualizaciones import GestorVisualizaciones
from manejaMiembros import GestorMiembros
from os import path

def menu():
    """Menu de opciones"""
    op=int(input("""
                                    MENU
        [1] Averiguar total de minutos visualizados en función a el correo electrónico ingresado
        [2] Mostrar Nombre, Apellido y correo electrónico de los miembros que realizaron visualizaciones simultaneas 
        [0] Salir
        -> """))
    return op

if __name__ == '__main__':
    GM = GestorMiembros(17)
    GM.cargar(path.dirname(__file__) + "/Miembros.csv")
    GV = GestorVisualizaciones()
    GV.cargar(path.dirname(__file__) + "/Visualizaciones.csv")
    #print(GM)
    #print(GV)
    opcion = menu()
    while opcion != 0:
        if opcion == 1:
            GM.mostrarTotalMinutos(GV)
        elif opcion == 2:
            GV.mostrarDatosSimultaneas(GM)
        else:
            print("Opcion no Válida")
        opcion = menu()