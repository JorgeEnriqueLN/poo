class Miembro:
    __Id : int
    __Nya: str
    __Email: str

    def __init__(self, id: int, nya: str, email: str):
        self.__Id = id
        self.__Nya = nya
        self.__Email = email

    def getId(self):
        return self.__Id
    
    def getNya(self):
        return self.__Nya
    
    def getEmail(self):
        return self.__Email
    
    def __str__(self):
        return f'Id del Miembro: {self.__Id}, Nombre y Apellido: {self.__Nya}, Correo electronico: {self.__Email}'