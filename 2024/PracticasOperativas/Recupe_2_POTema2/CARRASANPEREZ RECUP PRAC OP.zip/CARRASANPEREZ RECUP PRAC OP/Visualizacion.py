class Visualizacion:
    __IdMiem: int
    __IdPeli: str
    __Fecha: str
    __Hora: str
    __MinVisua: int

    def __init__(self, idmiem: int, idpeli: str, fecha: str, hora: str,  minvisua: int):
        self.__IdMiem = idmiem
        self.__IdPeli = idpeli
        self.__Fecha = fecha
        self.__Hora = hora
        self.__MinVisua = minvisua

    def getIdMiem(self):
        return self.__IdMiem
    
    def getIdPeli(self):
        return self.__IdPeli
    
    def getFecha(self):
        return self.__Fecha
    
    def getHora(self):
        return self.__Hora
    
    def getMinVisua(self):
        return self.__MinVisua
    
    def __str__(self):
        return f'Id Miembro: {self.__IdMiemb}, Id Pelicula: {self.__IdPeli}, Fecha: {self.__Fecha}, Hora: {self.__Hora}, Minutos de visualizacion: {self.__MinVisua}'
    
    def __eq__(self, otro):
        band = False
        if self.__IdMiem == otro.__IdMiem and self.FechaHora == otro.__FechaHora:
            band = True
        return band