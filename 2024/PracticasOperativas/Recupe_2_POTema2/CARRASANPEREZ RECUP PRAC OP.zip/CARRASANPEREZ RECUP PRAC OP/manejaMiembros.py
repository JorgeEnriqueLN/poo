from Miembro import Miembro
import numpy as np
import csv

class GestorMiembros:
    __Miembros: np.ndarray[Miembro, np.dtype[object]]
    __cantidad: int
    __dimension: int

    def __init__(self, dim: int):
        self.__Miembros = np.empty(dim, dtype = Miembro )
        self.__dimension = dim
        self.__cantidad = 0

    def agregarMiem(self, miem):
        self.__Miembros[self.__cantidad] = miem
        self.__cantidad +=1

    def cargar(self, ruta):
        archi = open(ruta)
        reader = csv.reader(archi, delimiter=";")
        band = True
        for fila in reader:
            if band:
                band = not band
            else:
                miem = Miembro(int(fila[0]),fila[1],(fila[2]))
                self.agregarMiem(miem)

    def __str__(self):
        s = ""
        for miem in self.__Miembros:
            s += str(miem) + "\n"
        return s
    
    def mostrarTotalMinutos(self, gv):
        correo = input("ingrese correo electrónico a consultar: ")
        i = 0
        while i < len(self.__Miembros) and self.__Miembros[i].getEmail() != correo:
            i += 1
        if i < len(self.__Miembros):
            gv.mostrarMinutos(self.__Miembros[i].getId())
        else:
            print('Error')

    def mostrarDatos(self, id: int):
        i = 0
        while i < len(self.__Miembros) and self.__Miembros[i].getId() != id:
            i += 1

        if i < len(self.__Miembros):
            print(f"Nya : {self.__Miembros[i].getNya()}, Correo: {self.__Miembros[i].getEmail()}")